jQuery(document).ready(function () {
  // Superfish Menu
  $('#navigation').superfish({
    animation:     {opacity:'show',height:'show'},   
    animationOut:  {opacity:'hide'},   
    speed:         'normal',
    speedOut:      'normal',
    delay:         0, 
    autoArrows:    false          
  }); 
 
  // Load Vegas Plugin
  $.vegas('slideshow', {
    backgrounds:[
      { src:'images/background-1.jpg', fade:2000},
      { src:'images/background-2.jpg', fade:2000}
    ]
  })('overlay', {
    src:'assets/img/overlay.png'
  }); 
 
});